Como executar?

- Abra na sua IDE e execute o projeto.

ou

-Abra o lista03/src terminal e digite make
