Para compilar os arquivos é necessário instalar java em seu computador
https://www.oracle.com/java/technologies/downloads/

Depois de instalado, selecione o arquivo .java e abra em uma ide, ou terminal, e digite o comando:
javac nome_do_arquivo.java
java nome_do_arquivo

Sendo nome_do_arquivo o nome do arquivo que você deseja compilar e rodar.
